library(dplyr)
library(tidyr)
library(data.table)
library(ggplot2)
library(LAVA)
library(ggsci)
library(showtext)
library(sysfonts)
library(purrr)
select = dplyr::select
col = pal_npg("nrc")(10)
font_add("MetroSans", "MetroSans-Regular.ttf")
showtext_auto()
coverage_by_group = fread("/Path/to/Fig2d.txt")
pcoverage = ggplot(coverage_by_group, aes(x = factor(setting), y = coverage)) +
  geom_hline(yintercept = 0.95, linetype = "dashed", color = "black") +
  geom_boxplot(fill = col[1], color = "black", outlier.size = 0.1) +
  labs(
    title = "",
    x = "",
    y = "Coverage for 95% LCI"
  ) +
  scale_y_continuous(
    breaks = c(.1,.3,0.5, .7,.9), # Specify y-axis breaks
    labels = c(".1",".3",".5", ".7", ".9")  # Specify y-axis labels
  )+
  theme_classic() +
  theme(
    strip.text = element_text(size = 12),
    axis.title = element_text(size = 12),
    axis.text.x = element_blank(),  # Rotate x-axis labels for readability
    axis.text.y = element_text(size = 12,family = "MetroSans"),
    plot.title = element_text(size = 12, hjust = 0.5),
    text = element_text(family = "MetroSans")
  )
pcoverage 

