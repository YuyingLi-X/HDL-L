library(dplyr)
library(tidyr)
library(data.table)
library(ggplot2)
library(LAVA)
library(ggsci)
library(showtext)
library(sysfonts)
library(purrr)
select = dplyr::select
col = pal_npg("nrc")(10)
font_add("MetroSans", "MetroSans-Regular.ttf")

time_cumulative= fread("/Path/to/Fig1f.txt")
ptime = ggplot(time_cumulative, aes(x = sim, y = hours, color = method)) +
  geom_line(size=1.6) +
  labs(
    x = "Simulation repeats",
    y = "Cumulative computation time",
    title =expression(plain("(")~x~100~hours~plain(")"))
  ) +
  theme_classic()+
  scale_color_manual(values = c("HDL" = col[1], "LAVA" = col[2]))+
  scale_y_continuous(
    breaks = default_breaks*100,
    labels = default_breaks
  ) +
  theme(legend.position = "none",
        #axis.text.x = element_text(angle = 45, hjust = 1),  # Rotate x-axis text labels
        axis.title.x = element_text(size = 12, color = "black"),  # Remove x-axis title
        axis.title.y = element_text(size = 12, color = "black"),  # Change Y-axis title size and color
        axis.text.x = element_text(size = 12, color = "black"),  # Change X-axis text size and color
        axis.text.y = element_text(size = 12, color = "black"),  # Change Y-axis text size and color
        axis.line = element_line(color = "black"),
        strip.text = element_text(size =12, color = "black"),
        text = element_text(family = "MetroSans"))
ptime
