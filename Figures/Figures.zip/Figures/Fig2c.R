library(dplyr)
library(tidyr)
library(data.table)
library(ggplot2)
library(ggsci)
library(showtext)
library(sysfonts)
library(purrr)

col = pal_npg("nrc")(10)
font_add("MetroSans", "MetroSans-Regular.ttf")
showtext_auto()
combined_se = fread("/Path/to/Fig1e.txt")
combined_se$nsnps_group <- factor(combined_se$nsnps_group, 
                                  levels = c("0-200", "200-400", "400-600", "600-800", ">800"))

# Create the combined plot
pbias_combined <- ggplot(combined_se, aes(x = nsnps_group, y = bias_mean_scaled, 
                                          color = method, shape = trait, 
                                          group = interaction(method, trait))) +
  geom_segment(aes(y = ymin_scaled, yend = ymax_scaled), 
               position = position_dodge(width = 0.7), size = 0.8) +
  geom_point(position = position_dodge(width = 0.7), size = 2.5) +
  scale_y_continuous(
    breaks = seq(0, 8, 2),# Adjust as appropriate
    label = c("0","2","4","6","8")
  ) +
  labs(
    x = "Number of SNPs",
    y = "Bias of estimated heritabilities"
  ) +
  scale_color_manual(
    values = c("HDL-L" = col[1], "LAVA" = col[2])
  ) +
  scale_shape_manual(values = c("h1" = 15, "h2" = 16)) +  # Different shapes for h1 and h2
  theme_classic() +
  theme(
    axis.text.x = element_text(color = "black", size = 12, angle = 45, vjust = 1, hjust = 1),
    axis.text.y = element_text(color = "black", size = 12),
    axis.title = element_text(color = "black", size = 12),
    axis.line = element_line(color = "black"),
    text = element_text(family = "MetroSans", size = 12),
    strip.text = element_blank(),
    strip.background = element_blank(),
    panel.border = element_blank(),
    panel.spacing = unit(0.5, "lines"),
    legend.position = "none",
    legend.title = element_blank(),
    legend.text = element_text(size = 12)
  ) 
pbias_combined

