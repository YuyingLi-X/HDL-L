library(dplyr)
library(tidyr)
library(data.table)
library(ggplot2)
library(LAVA)
library(ggsci)
library(showtext)
library(sysfonts)
library(purrr)
library(ggforce)
library(ggrepel)

select = dplyr::select
col = pal_npg("nrc")(10)
font_add("MetroSans", "MetroSans-Regular.ttf")
showtext_auto()

coloc_data = fread("Path/to/Fig3.txt")
data1 = coloc_data %>% filter(cate =="HDL-L")
data2 = coloc_data %>% filter(cate =="LAVA")

pie <- ggplot() +
  geom_arc_bar(
    data = data1,
    stat = "pie",
    aes(
      x0 = 0, y0 = 0, r0 = 0, r = 2,
      amount = percentage,
      fill = Method,
      color = Method
    ),
    show.legend = FALSE
  ) +
  theme_void() +  
  coord_fixed() +
  scale_fill_manual(
    values = c(
      "Colocalized" = alpha(col[1], 0.9),
      "Non-colocalized" = alpha(col[1], 0.5)
    )
  ) +
  scale_color_manual(
    values = c(
      "Colocalized" = alpha(col[1], 0.9),
      "Non-colocalized" = alpha(col[1], 0.5)
    )
  ) +
  geom_text_repel(
    data = data1,
    aes(
      x = -2 * sin(mid_angle),
      y = 4 * cos(mid_angle),
      label = anno
    ),
    nudge_y = 0.01,
    size = 5,
    show.legend = FALSE
  ) +
  theme(
    panel.border = element_blank(),
    legend.key.width = unit(0.5, "cm"),
    legend.key.height = unit(0.5, "cm"),
    legend.position = "none",
    legend.title = element_blank(),
    text = element_text(family = "MetroSans", size = 12)
  )


pie


pie2 <- ggplot() +
  geom_arc_bar(
    data = data2,
    stat = "pie",
    aes(
      x0 = 0, y0 = 0, r0 = 0, r = 2,
      amount = percentage,
      fill = Method,
      color = Method
    ),
    show.legend = FALSE
  ) +
  theme_void() +  
  coord_fixed() +
  scale_fill_manual(
    values = c(
      "Colocalized" = alpha(col[2], 1),
      "Non-colocalized" = alpha(col[2], 0.5)
    )
  ) +
  scale_color_manual(
    values = c(
      "Colocalized" = alpha(col[2], 1),
      "Non-colocalized" = alpha(col[2], 0.5)
    )
  ) +
  geom_text_repel(
    data = data2,
    aes(
      x = -2 * sin(mid_angle),
      y = 4 * cos(mid_angle),
      label = anno
    ),
    nudge_y = 0.01,
    size = 5,
    show.legend = FALSE
  ) +
  theme(
    panel.border = element_blank(),
    legend.key.width = unit(0.5, "cm"),
    legend.key.height = unit(0.5, "cm"),
    legend.position = "none",
    legend.title = element_blank(),
    text = element_text(family = "MetroSans", size = 12)
  )

pie2

