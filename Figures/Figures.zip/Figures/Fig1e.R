library(dplyr)
library(tidyr)
library(data.table)
library(ggplot2)
library(LAVA)
library(ggsci)
library(showtext)
library(sysfonts)
library(purrr)
select = dplyr::select
col = pal_npg("nrc")(10)
font_add("MetroSans", "MetroSans-Regular.ttf")
showtext_auto()
median_mse = fread("/Users/yuyingli/Documents/YuyingLi_PhD/Study_1/Revise/Data/Fig1e.txt")
pline <- ggplot(
  median_mse, 
  aes(
    x = rg.0,
    y = medianmse,
    color = method,
    linetype = parameter,
    shape = parameter,
    group = interaction(method, parameter)
  )
) +
  geom_line(size = 0.1) +
  geom_point(size = 2) +
  facet_wrap(~ setting, nrow = 1, labeller = label_parsed) +
  labs(
    title = "",
    subtitle = "",
    x = "True genome-wide genetic correlation",
    y = "Genome-Wide Median MSE",
    linetype = "Parameter",
    shape = "Parameter",
    color = "Method"
  ) +
  scale_x_continuous(
    breaks = c(-1, -0.5, 0, 0.5, 1),  # Specify x-axis breaks
    labels = c("-1", "-.5", "0", ".5", "1")  # Specify x-axis labels
  ) +
  scale_y_log10(
    breaks = c(0.1e-7, 0.1e-6, 0.1),labels = c(expression(".1"~x~10^-7), expression(".1"~x~10^-6), ".1")
  ) +
  theme_classic() +
  ggbreak::scale_y_break(c(1e-7, 0.005)) +  # Remove secondary axi
  theme(
    axis.text = element_text(color = "black", size = 12),
    axis.title = element_text(color = "black", size = 12),
    axis.line = element_line(color = "black"),
    text = element_text(family = "MetroSans", size = 12),
    strip.text = element_blank(),
    #strip.text = element_text(size = 12, family ="MetroSans"),
    strip.background = element_blank(),
    panel.border = element_blank(),
    panel.spacing = unit(0.5, "lines"),
    legend.position = "none",
    legend.title = element_blank(),  # Adjust legend title size
    legend.text = element_text(size = 12) ,
    axis.line.y.right = element_blank(),
    axis.text.y.right = element_blank(),
    axis.ticks.y.right = element_blank()
  ) +
  scale_color_manual(values = c("HDL-L" = col[1], "LAVA" = col[2])) +
  scale_linetype_manual(
    values = c("Genetic Correlation" = "solid", "Genetic covariance" = "solid", "Heritability of trait 1" = "solid", "Heritability of trait 2" = "solid"),
    labels = c("Genetic covariance", "Heritability of trait 1", "Heritability of trait 2")
  ) +
  scale_shape_manual(
    values = c("Genetic Correlation" = 15, "Genetic covariance" = 17, "Heritability of trait 1" = 3, "Heritability of trait 2" = 4),
    labels = c("Genetic Correlation", "Genetic covariance", "Heritability of trait 1", "Heritability of trait 2")
  )
# Print and save the plot
print(pline)

heatmap_data <- data.frame(
  setting = factor(1:6),
  h1 = c(.2, .2, .3, .5, .6, .7),
  h2 = c(.4, .8, .3, .5, .8, .7)
)

# Convert to long format
heatmap_long <- heatmap_data %>%
  pivot_longer(
    cols = c(h1,h2),
    names_to = "Trait",
    values_to = "Heritability"
  )

# Assign x and y positions
heatmap_long <- heatmap_long %>%
  mutate(
    x = as.numeric(setting),
    y = ifelse(Trait == "h1", 2, 1)
  )

# Create the heatmap plot with formatted labels
heatmap_plot <- ggplot(heatmap_long, aes(x = x, y = y, fill = Heritability)) +
  geom_tile(color = "white") +
  geom_text(
    aes(label = sub("^0\\.", ".", as.character(Heritability))),
    color = "black",
    size = 4
  ) +
  scale_fill_gradient(low = alpha(col[1], 0.3), high = col[1]) +
  scale_y_continuous(
    breaks = 1:2,
    labels = c(expression(italic(h)[2]^2), expression(italic(h)[1]^2)),
    #labels = c("True heritability of trait 2", "True heritability of trait 1"),
    expand = c(0, 0)
  ) +
  scale_x_continuous(
    breaks = 1:6,
    labels = NULL,  # Optional: add labels if desired
    expand = c(0, 0)
  ) +
  theme_minimal() +
  theme(
    axis.title = element_blank(),
    axis.text = element_text(color = "black", size = 12),
    text = element_text(family = "MetroSans", size = 12),
    axis.text.x = element_blank(),
    axis.text.y = element_text(size = 12, family = "Arial"),
    axis.ticks = element_blank(),
    panel.grid = element_blank(),
    legend.position = "none",
    plot.margin = margin(t = -5, r = 0, b = 0, l = 0, unit = "pt")
  )

heatmap_plot
lineheat = pline / heatmap_plot + plot_layout(heights = c(3, 0.6))

