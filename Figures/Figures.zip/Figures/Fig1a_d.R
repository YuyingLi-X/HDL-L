library(dplyr)
library(tidyr)
library(data.table)
library(ggplot2)
library(ggsci)
library(showtext)
library(sysfonts)
library(purrr)

col = pal_npg("nrc")(10)
font_add("MetroSans", "MetroSans-Regular.ttf")
showtext_auto()

setwd("/path/to/Fig1a_d.txt")
# Define the parameter pairs
param_pairs <- list(
  list(est = "Heritability_1", true = "h1_piece", label = "Heritability 1"),
  list(est = "Heritability_2", true = "h2_piece", label = "Heritability 2"),
  list(est = "h12", true = "gcov_piece", label = "Genetic Covariance"),
  list(est = "rg", true = "rg_piece", label = "Genetic Correlation" )
)


plotdat22 = fread("/Users/yuyingli/Documents/YuyingLi_PhD/Study_1/Revise/Data/Fig1a_d.txt")
#### Get SSE text 

mse_results <- map_dfr(param_pairs, function(pair) {
  plotdat22 %>%
    group_by(method) %>%
    summarize(
      parameter = pair$label,
      mse = mean((!!sym(pair$true) - !!sym(pair$est))^2, na.rm = TRUE),
      na_count = sum(is.na(!!sym(pair$true)) | is.na(!!sym(pair$est))),
      total_count = n(),
      non_na_count = sum(!is.na(!!sym(pair$true)) & !is.na(!!sym(pair$est)))
    )
})

plotdat22$method <- factor(plotdat22$method, levels = c("LAVA", "HDL-L"))
plotdat22 <- plotdat22 %>%
  arrange(method)
# Extract sse values for Heritability 1

lava_sse <- mse_results %>% filter(method == "LAVA", parameter == "Heritability 1") %>% pull(mse)
hdl_l_sse <- mse_results %>% filter(method == "HDL-L", parameter == "Heritability 1") %>% pull(mse)

ph1point = ggplot(plotdat22, aes(x = h1_piece, y = Heritability_1, color = method, shape = method)) +
  geom_smooth(data = subset(plotdat22, method == "LAVA"), aes(group = method), color = col[2], size = 1.5) +
  geom_smooth(data = subset(plotdat22, method == "HDL-L"), aes(group = method), color = col[1], size = 1.5) +
  geom_point(alpha=0.3) +
  geom_abline(intercept = 0, slope = 1, linetype = "dashed", color = "black") +
  theme_classic() +
  labs(x= "", y ="", title = "") +  # Correct y-axis label expression
  scale_y_continuous(
    breaks = seq(0, 3e-3, by = 1e-3), # Specify y-axis breaks
    labels = c("0", "1", "2", "3")  # Specify y-axis labels
  )+
  scale_x_continuous(
    breaks = seq(0, 1e-3, by = 0.5e-3), # Specify y-axis breaks
    labels = c("0", ".5", "1")  # Specify y-axis labels
  )+
  scale_color_manual(values = c("HDL-L" = col[1], "LAVA" = col[2])) +
  scale_shape_manual(values = c("HDL-L" = 16, "LAVA" = 17)) +
  theme(legend.position = "none",
        axis.text = element_text(color = "black", size = 12),
        axis.title = element_text(color = "black", size = 12),
        axis.line = element_line(color = "black"),
        strip.text = element_text(size = 12),
        text = element_text(family = "MetroSans")) +
  guides(color = guide_legend(override.aes = list(shape = c(16, 17))))

print(ph1point)


# Extract sse values for Heritability 2
lava_sse <- mse_results %>% filter(method == "LAVA", parameter == "Heritability 2") %>% pull(mse)
hdl_l_sse <- mse_results %>% filter(method == "HDL-L", parameter == "Heritability 2") %>% pull(mse)



ph2point = ggplot(plotdat22, aes(x = h2_piece, y = Heritability_2, color = method, shape = method)) +
  geom_smooth(data = subset(plotdat22, method == "LAVA"), aes(group = method), color = col[2], size = 1.5 ) +
  geom_smooth(data = subset(plotdat22, method == "HDL-L"), aes(group = method), color = col[1], size = 1.5) +
  geom_point(alpha= .3) +
  geom_abline(intercept = 0, slope = 1, linetype = "dashed", color = "black") +
  theme_classic() +
  labs(x= "", y = expression(Estimated~values~plain("(")~x~10^-3~plain(")"))) +  # Correct y-axis label expression
  scale_y_continuous(
    breaks = seq(0, 3e-3, by = 1e-3), # Specify y-axis breaks
    labels = c("0", "1", "2", "3")  # Specify y-axis labels
  )+
  scale_x_continuous(
    breaks = seq(0, 1e-3, by = 0.5e-3), # Specify y-axis breaks
    labels = c("0", ".5", "1")  # Specify y-axis labels
  )+
  scale_color_manual(values = c("HDL-L" = col[1], "LAVA" = col[2])) +
  scale_shape_manual(values = c("HDL-L" = 16, "LAVA" = 17)) +
  theme(legend.position = "none",
        axis.text = element_text(color = "black", size = 12),
        axis.title = element_text(color = "black", size = 12),
        axis.line = element_line(color = "black"),
        strip.text = element_text(size = 12),
        text = element_text(family = "MetroSans"),) +
  guides(color = guide_legend(override.aes = list(shape = c(16, 17)))) +
  coord_cartesian(ylim = c(0, 2.9e-3))
print(ph2point)



# Extract mse values for each method
lava_sse <- mse_results %>% filter(method == "LAVA", parameter == "Genetic Covariance") %>% pull(mse)
hdl_l_sse <- mse_results %>% filter(method == "HDL-L", parameter == "Genetic Covariance") %>% pull(mse)
# Combine MSE values into a data frame
mse_data <- data.frame(
  mse = c(lava_sse, hdl_l_sse),
  method = factor(rep(c("LAVA", "HDL-L"), times = c(length(lava_sse), length(hdl_l_sse))))
)


# Similarly for pgcovpoint
pgcovpoint = ggplot(plotdat22, aes(x = gcov_piece, y = h12, color = method, shape = method)) +
  geom_smooth(data = subset(plotdat22, method == "LAVA"), aes(group = method), color = col[2], size = 1.5 ) +
  geom_smooth(data = subset(plotdat22, method == "HDL-L"), aes(group = method), color = col[1], size = 1.5) +
  geom_point(alpha= .3) +
  geom_abline(intercept = 0, slope = 1, linetype = "dashed", color = "black") +
  theme_classic() +
  labs(x= "", y = "") +  # Correct y-axis label expression
  scale_y_continuous(
    breaks = seq(-2e-3, 2e-3, by = 1e-3), # Specify y-axis breaks
    labels = c("-2", "-1", "0", "1", "2")  # Specify y-axis labels
  )+
  scale_x_continuous(
    breaks = seq(-1e-3, 1e-3, by = 0.5e-3), # Specify y-axis breaks
    labels = c("-1", "-.5"," 0", ".5", "1")  # Specify y-axis labels
  )+
  scale_color_manual(values = c("HDL-L" = col[1], "LAVA" = col[2])) +
  scale_shape_manual(values = c("HDL-L" = 16, "LAVA" = 17)) +
  theme(legend.position = "none",
        axis.text = element_text(color = "black", size = 12),
        axis.title = element_text(color = "black", size = 12),
        axis.line = element_line(color = "black"),
        strip.text = element_text(size = 12),
        text = element_text(family = "MetroSans")) +
  guides(color = guide_legend(override.aes = list(shape = c(16, 17)))) 
print(pgcovpoint)

lava_sse = mse_results %>% filter(method == "LAVA", parameter == "Genetic Correlation") %>% pull(mse)
hdl_l_sse = mse_results %>% filter(method == "HDL-L", parameter == "Genetic Correlation") %>% pull(mse)

plotdat22$method <- factor(plotdat22$method, levels = c("HDL-L", "LAVA"))
plotdat22 <- plotdat22 %>%
  arrange(method)


prgpoint = ggplot(plotdat22, aes(x = rg_piece, y = rg, color = method, shape = method)) +
  geom_point(alpha= .2, size = 0.1) +
  geom_abline(intercept = 0, slope = 1, linetype = "dashed", color = "black") +
  geom_smooth(data = subset(plotdat22, method == "LAVA"), aes(group = method), color = col[2], size = 1.5 ) +
  geom_smooth(data = subset(plotdat22, method == "HDL-L"), aes(group = method), color = col[1], size = 1.5) +
  theme_classic() +
  labs(x= expression(True~values~plain("(")~x~10^-3~plain(")")), y = "") +  # Correct y-axis label expression
  scale_y_continuous(
    breaks = seq(-1, 1, by = .5), # Specify y-axis breaks
    labels = c("-1", "-.5", "0", ".5", "1")  # Specify y-axis labels
  )+
  scale_x_continuous(
    breaks = seq(-1, 1, by = 0.5), # Specify y-axis breaks
    labels = c("-1", "-.5"," 0", ".5", "1")  # Specify y-axis labels
  )+
  scale_color_manual(values = c("HDL-L" = col[1], "LAVA" = col[2])) +
  scale_shape_manual(values = c("HDL-L" = 16, "LAVA" = 17)) +
  theme(legend.position = "none",
        axis.text = element_text(color = "black", size = 12),
        axis.title = element_text(color = "black", size = 12),
        axis.line = element_line(color = "black"),
        strip.text = element_text(size = 12),
        text = element_text(family = "MetroSans")) +
  guides(color = guide_legend(override.aes = list(shape = c(16, 17)))) 

print(prgpoint)


plotdat22$method <- factor(plotdat22$method, levels = c("HDL-L","LAVA"))
plotdat22 <- plotdat22 %>%
  arrange(method)
plotdat22 = plotdat22 %>% mutate(biasrg = rg - rg_piece, biash1 = Heritability_1 - h1_piece, biash2 = Heritability_2 - h2_piece, biasgcov = h12 - gcov_piece)

ph1box = ggplot(plotdat22, aes(x=as.factor(piece), y=biash1, fill=method)) + 
  geom_boxplot(outlier.colour = "white") +
  geom_hline(yintercept = 0, linetype = "dashed", color = "black") +  # Add a horizontal line at y=0
  theme_classic()+
  labs(x = "", y = "", title = expression(Local~heritability~of~trait~1~plain("(")*x~10^-3*plain(")")))+
  # scale_y_continuous(labels = function(x) format(x * 1000)) +  
  scale_y_continuous(
    breaks = seq(0, 1e-3, by = 0.5e-3), # Specify y-axis breaks
    labels = c("0", ".5", "1")  # Specify y-axis labels
  )+
  scale_fill_manual(values = c("HDL-L" = col[1], "LAVA" = col[2]))+
  theme(legend.position = "none",
        #axis.text.x = element_text(angle = 45, hjust = 1),  # Rotate x-axis text labels
        axis.title.x = element_text(size = 12, color = "black"),  # Remove x-axis title
        axis.title.y = element_text(size = 12, color = "black"),  # Change Y-axis title size and color
        axis.text.x = element_text(size = 12, color = "black"),  # Change X-axis text size and color
        axis.text.y = element_text(size = 12, color = "black"),  # Change Y-axis text size and color
        axis.line = element_line(color = "black"),
        strip.text = element_text(size =12, color = "black"),
        text = element_text(family = "MetroSans"))+ # Sets the color of axis lines to black 
  coord_cartesian(ylim = c(-0.5e-3, 1.5e-3))

print(ph1box)

ph2box = ggplot(plotdat22, aes(x=as.factor(piece), y=biash2, fill=method)) + 
  geom_boxplot(outlier.colour = "white") +
  geom_hline(yintercept = 0, linetype = "dashed", color = "black") +  # Add a horizontal line at y=0
  theme_classic()+
  labs(x = "", y = "Estimated minus true values", title = expression(Local~heritability~of~trait~2~plain("(")*x~10^-3*plain(")")))+
  #scale_y_continuous(labels = function(x) format(x * 1000)) +  
  scale_fill_manual(values = c("HDL-L" = col[1], "LAVA" = col[2]))+
  scale_y_continuous(
    breaks = seq(0, 1e-3, by = 0.5e-3), # Specify y-axis breaks
    labels = c("0", ".5", "1")  # Specify y-axis labels
  )+
  theme(legend.position = "none",
        #axis.text.x = element_text(angle = 45, hjust = 1),  # Rotate x-axis text labels
        axis.title.x = element_text(size = 12, color = "black"),  # Remove x-axis title
        axis.title.y = element_text(size = 12, color = "black"),  # Change Y-axis title size and color
        axis.text.x = element_text(size = 12, color = "black"),  # Change X-axis text size and color
        axis.text.y = element_text(size = 12, color = "black"),  # Change Y-axis text size and color
        axis.line = element_line(color = "black"),
        strip.text = element_text(size =12, color = "black"),
        text = element_text(family = "MetroSans"))+# Sets the color of axis lines to black 
  coord_cartesian(ylim = c(-0.5e-3, 1.5e-3))
print(ph2box)


pgcovbox = ggplot(plotdat22, aes(x=as.factor(piece), y=biasgcov, fill=method)) + 
  geom_boxplot(outlier.colour = "white") +
  geom_hline(yintercept = 0, linetype = "dashed", color = "black") +  # Add a horizontal line at y=0
  theme_classic()+
  labs(x = "", y = "", title = expression(Local~genetic~covariance~plain("(")*x~10^-3*plain(")")))+
  scale_y_continuous(
    breaks = seq(-0.5e-3, 0.5e-3, by = 0.5e-3), # Specify y-axis breaks
    labels = c("-.5", "0", ".5")  # Specify y-axis labels
  )+
  # scale_y_continuous(labels = function(x) format(x * 1000)) +   
  scale_fill_manual(values = c("HDL-L" = col[1], "LAVA" = col[2]))+
  theme(legend.position = "none",
        #axis.text.x = element_text(angle = 45, hjust = 1),  # Rotate x-axis text labels
        axis.title.x = element_text(size = 12, color = "black"),  # Remove x-axis title
        axis.title.y = element_text(size = 12, color = "black"),  # Change Y-axis title size and color
        axis.text.x = element_text(size = 12, color = "black"),  # Change X-axis text size and color
        axis.text.y = element_text(size = 12, color = "black"),  # Change Y-axis text size and color
        axis.line = element_line(color = "black"),
        strip.text = element_text(size =12, color = "black"),
        text = element_text(family = "MetroSans"))+
  coord_cartesian(ylim = c(-0.6e-3, 0.6e-3))
print(pgcovbox)

prgbox = ggplot(plotdat22, aes(x=as.factor(piece), y=biasrg, fill=method)) +
  geom_boxplot(outlier.colour = "white") +
  geom_hline(yintercept = 0, linetype = "dashed", color = "black") +  # Add a horizontal line at y=0
  theme_classic()+
  labs(x = "Chromosome 22 regions", y = "", title = "Local genetic correlation")+
  scale_y_continuous(
    breaks = seq(-.5, .5, by = 0.5), # Specify y-axis breaks
    labels = c("-.5", "0", ".5")  # Specify y-axis labels
  )+
  # scale_y_continuous(labels = function(x) format(x * 1000)) +
  scale_fill_manual(values = c("HDL-L" = col[1], "LAVA" = col[2]))+
  theme(legend.position = "none",
        #axis.text.x = element_text(angle = 45, hjust = 1),  # Rotate x-axis text labels
        axis.title.x = element_text(size = 12, color = "black"),  # Remove x-axis title
        axis.title.y = element_text(size = 12, color = "black"),  # Change Y-axis title size and color
        axis.text.x = element_text(size = 12, color = "black"),  # Change X-axis text size and color
        axis.text.y = element_text(size = 12, color = "black"),  # Change Y-axis text size and color
        axis.line = element_line(color = "black"),
        strip.text = element_text(size =12, color = "black"),
        text = element_text(family = "MetroSans"))+
  coord_cartesian(ylim = c(-1, 1))
print(prgbox)

