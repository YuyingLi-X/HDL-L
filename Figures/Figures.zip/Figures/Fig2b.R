library(dplyr)
library(tidyr)
library(data.table)
library(ggplot2)
library(LAVA)
library(ggsci)
library(showtext)
library(sysfonts)
library(purrr)
select = dplyr::select
col = pal_npg("nrc")(10)
font_add("MetroSans", "MetroSans-Regular.ttf")
showtext_auto()
tpr = fread("/Path/to/Fig2b.txt")
# Create the boxplot
p <- ggplot(tpr, aes(x = factor(setting), y = tpr, colour =  method, fill = method)) +
  geom_boxplot(color = "black", outlier.size = 0.1, outlier.colour = "white")+
  labs(
    x = "",
    y = "True positive rate",
    title = ""
  ) +
  scale_fill_manual(values = c("HDL-L" = col[1], "LAVA" = col[2]))+
  scale_y_continuous(
    breaks = c(0, 0.3, 0.6, 0.9), # Specify y-axis breaks
    labels = c("0", ".3", ".6", ".9")  # Specify y-axis labels
  )+
  theme_classic()+
  theme(
    axis.text = element_text(color = "black", size = 12),
    axis.title = element_text(color = "black", size = 12),
    axis.line = element_line(color = "black"),
    text = element_text(family = "MetroSans", size = 12),
    strip.text = element_blank(),
    axis.text.x = element_blank(),
    #strip.text = element_text(size = 12, family ="MetroSans"),
    strip.background = element_blank(),
    panel.border = element_blank(),
    panel.spacing = unit(0.5, "lines"),
    legend.position = "none",
    legend.title = element_blank(),  # Adjust legend title size
    legend.text = element_text(size = 12) 
  ) 



heatmap_data <- data.frame(
  setting = factor(1:6),
  h1 = c(.2, .2, .3, .5, .6, .7),
  h2 = c(.4, .8, .3, .5, .8, .7)
)

# Convert to long format
heatmap_long <- heatmap_data %>%
  pivot_longer(
    cols = c(h1,h2),
    names_to = "Trait",
    values_to = "Heritability"
  )

# Assign x and y positions
heatmap_long <- heatmap_long %>%
  mutate(
    x = as.numeric(setting),
    y = ifelse(Trait == "h1", 2, 1)
  )

# Create the heatmap plot with formatted labels
heatmap_plot <- ggplot(heatmap_long, aes(x = x, y = y, fill = Heritability)) +
  geom_tile(color = "white") +
  geom_text(
    aes(label = sub("^0\\.", ".", as.character(Heritability))),
    color = "black",
    size = 4
  ) +
  scale_fill_gradient(low = alpha(col[1], 0.3), high = col[1]) +
  scale_y_continuous(
    breaks = 1:2,
    labels = c(expression(italic(h)[2]^2), expression(italic(h)[1]^2)),
    #labels = c("True heritability of trait 2", "True heritability of trait 1"),
    expand = c(0, 0)
  ) +
  scale_x_continuous(
    breaks = 1:6,
    labels = NULL,  # Optional: add labels if desired
    expand = c(0, 0)
  ) +
  theme_minimal() +
  theme(
    axis.title = element_blank(),
    axis.text = element_text(color = "black", size = 12),
    text = element_text(family = "MetroSans", size = 12),
    axis.text.x = element_blank(),
    axis.text.y = element_text(size = 12, family = "Arial"),
    axis.ticks = element_blank(),
    panel.grid = element_blank(),
    legend.position = "none",
    plot.margin = margin(t = -5, r = 0, b = 0, l = 0, unit = "pt")
  )

ptpr = p / heatmap_plot + plot_layout(height = c(3,0.6))

ptpr
